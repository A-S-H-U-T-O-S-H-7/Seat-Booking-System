import JagannathPancharatra from "@/components/pancha-ratra/PanchaRatra";
import React from "react";

function page() {
  return (
    <div>
      <JagannathPancharatra />
    </div>
  );
}

export default page;
