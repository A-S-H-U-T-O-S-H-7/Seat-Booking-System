import JagannathSchedule from '@/components/dailyevent/DailyEvent'
import React from 'react'

function page() {
  return (
    <div>
        
      <JagannathSchedule />
    </div>
  )
}

export default page
