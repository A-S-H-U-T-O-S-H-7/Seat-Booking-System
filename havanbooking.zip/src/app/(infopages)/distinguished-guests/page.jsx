import DistinguishedGuests from '@/components/distinguishedguests/DistinguishedGuests'
import React from 'react'

function page() {
  return (
    <div>
      <DistinguishedGuests/>
    </div>
  )
}

export default page
