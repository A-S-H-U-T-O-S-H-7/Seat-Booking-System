import RefundCancellationPolicy from '@/components/static-pages/RefundCancelPolicy'
import React from 'react'

function page() {
  return (
    <div>
      <RefundCancellationPolicy/>
    </div>
  )
}

export default page
