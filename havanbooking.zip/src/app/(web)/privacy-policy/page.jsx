import PrivacyPolicy from "@/components/static-pages/Privacy-Policy";

function page() {
  return (
    <div>
      <PrivacyPolicy />
    </div>
  );
}

export default page;
