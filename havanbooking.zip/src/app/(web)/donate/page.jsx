import DonationComponent from '@/components/donation/DonationPage'
import React from 'react'

function page() {
  return (
    <div>
      <DonationComponent />
    </div>
  )
}

export default page
