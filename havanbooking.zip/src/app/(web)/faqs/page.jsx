"use client"

import React from 'react'

import FAQ from '@/components/static-pages/Faqs'
import EventPass from '@/components/MemberPass';
import DonationReceipt from '@/components/Receipt';

function page() {
      
    
  return (
    <div>
      <FAQ />            
{/* <EventPass/>
<DonationReceipt /> */}
    </div>
  )
}

export default page
