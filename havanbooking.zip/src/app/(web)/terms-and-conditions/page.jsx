import TermsAndConditions from "@/components/static-pages/Terms-and-Conditions";
import React from "react";

function page() {
  return (
    <div>
      <TermsAndConditions />
    </div>
  );
}

export default page;
