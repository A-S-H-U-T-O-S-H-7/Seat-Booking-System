import Notice from '@/components/static-pages/Notice'
import React from 'react'

function page() {
  return (
    <div>
      <Notice/>
    </div>
  )
}

export default page
